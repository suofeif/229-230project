#!/user/bin/env python
# -*- coding:utf-8 -*-

import os
model_save_path = os.path.abspath('..') + "/data/"
train_data_path = os.path.abspath('..') + "/data/trainingset.csv"
validate_data_path = os.path.abspath('..') + "/data/validationset.csv"
test_data_path = os.path.abspath('..') + "/data/testa.csv"
test_data_predict_out_path = os.path.abspath('..') + "/output/testPredict.csv"
